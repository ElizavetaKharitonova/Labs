#include <iostream>
#include <ctime>

using namespace std;


void dbl_matrix_multiplication(double **a, double *b, double *c, int n){
   for (int i = 0; i < n; i++){
       for (int j = 0; j < n; j++){

          c[i] = c[i] + (a[i][j] * b[j]);

       }
    }
}


int main(){

    srand(time(0));

    int n = 0;
    const int UPPER_CONSTANT = 5;

    while(true){

            cout << "Enter your number n (not negative or zero): ";
            cin >> n;

            if(cin.fail() || n < 1){

                cin.clear();
                cin.ignore(32767,'\n');

            }else{
                break;
            }

    };

    double **A;
    double *B;
    double *C;
    A = new double *[n];
    B = new double[n];
    C = new double[n];

    cout << endl <<  "Massive B" << endl;

    for (int i=0; i < n; i++){

        A[i] = new double[n];
        B[i] = 0 + rand() % (UPPER_CONSTANT + 1);
        C[i] = 0;

        cout << B[i] << endl;
    }

    cout << endl <<  "Massive A" << endl;

    for(int i = 0; i < n; i++){

        for(int j = 0; j < n; j++){

            A[i][j] = 0 + rand() % (UPPER_CONSTANT + 1);
            cout << A[i][j] << "\t";

        }

        cout << endl;
    }

    cout << endl <<  "Massive C" << endl;

    dbl_matrix_multiplication(A, B, C, n);

    for(int i = 0; i < n; i++){
        cout << C[i] << endl;
    }


    delete[] A;
    delete[] B;
    delete[] C;

    return 0;
}
